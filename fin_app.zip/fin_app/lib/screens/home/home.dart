import 'dart:ui';
import 'package:fin_app/inside_app/junior_official/sector_choice.dart';
import 'package:fin_app/inside_app/senior_official/senior_official_login.dart';
import 'package:fin_app/inside_app/senior_official/sector_choice.dart';
import 'package:fin_app/inside_app/junior_official/sector_choice.dart';
import 'package:fin_app/screens/authenticate/sign_in_junior.dart';
import 'package:fin_app/screens/authenticate/sign_in_senior.dart';
import 'package:flutter/material.dart';
import 'package:fin_app/inside_app/junior_official/junior_official_login.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.5),
                image: DecorationImage(
                    image: AssetImage(''),
                    fit: BoxFit.fitHeight)),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 4.0, sigmaY: 4.0),
              child: Container(
                decoration: BoxDecoration(color: Colors.black.withOpacity(0.3)),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 210),
            width: double.infinity,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Text(
                    'Login',
                    style: TextStyle(
                      fontSize: 70.0,
                      color: Colors.white,
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.only(left: 20, right: 20, top: 100),
                    child: RaisedButton(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30.0)),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ChoiceSenior(),)
                        );
                      },
                      textColor: Colors.white,
                      padding: const EdgeInsets.all(0.0),
                      child: Container(
                        alignment: Alignment.center,
                        height: 75,
                        width: 400,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30.0),
                            gradient: LinearGradient(
                                colors: <Color>[Colors.blue[900],
                        Colors.blue[700],
                        Colors.blue[400],])),
                        padding: const EdgeInsets.all(20.0),
                        child: const Text(
                          "Senior Official",
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 25, fontFamily: 'Roboto'),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.only(left: 20, right: 20, top: 30),
                    child: RaisedButton(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30.0)),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ChoiceJunior()),
                        );
                      },
                      textColor: Colors.white,
                      padding: const EdgeInsets.all(0.0),
                      child: Container(
                        alignment: Alignment.center,
                        height: 75,
                        width: 400,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30.0),
                            gradient: LinearGradient(
                                colors: <Color>[Colors.blue[900],
                        Colors.blue[700],
                        Colors.blue[400],])),
                        padding: const EdgeInsets.all(20.0),
                        child: const Text(
                          "Junior Official",
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 25, fontFamily: 'Roboto'),
                        ),
                      ),
                    ),
                  ),
                ]),
          ),
          Container(
            margin: EdgeInsets.only(top: 720),
            width: double.infinity,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Container(
                    height: 100,
                    width: 100,
                    child: Image(image: AssetImage(''))),
                Container(
                    decoration: BoxDecoration(color: Colors.white),
                    height: 100,
                    width: 100,
                    child: Image(image: AssetImage('')))
              ],
            ),
          )
        ],
      ),
    );
  }
}
