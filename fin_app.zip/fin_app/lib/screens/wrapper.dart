import 'package:flutter/material.dart';
import 'package:fin_app/screens/home/home.dart';


class Wrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    
    return Home();
  }
}