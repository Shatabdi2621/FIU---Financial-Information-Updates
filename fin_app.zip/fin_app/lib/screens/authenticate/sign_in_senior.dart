import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:fin_app/inside_app/senior_official/senior_official_login.dart';

class LoginSeniorUser extends StatefulWidget {
  final String choice, sector;
  LoginSeniorUser({this.choice, this.sector});
  @override
  _LoginSeniorUserState createState() => _LoginSeniorUserState();
}

class _LoginSeniorUserState extends State<LoginSeniorUser> {

  String url;
  

  bool visible = false;

  // Getting value from TextField widget.
  final useridController = TextEditingController();
  final passwordController = TextEditingController();

  Future userLogin() async {
    // Showing CircularProgressIndicator.
    setState(() {
      visible = true;
    });

    
    // Getting value from Controller
    String userid = useridController.text;
    String password = passwordController.text;
    // SERVER LOGIN API URL
    if(widget.choice == 'banking'){
      
    url = '';
    } else if(widget.choice == 'insurance'){
      url = '';
    } else if(widget.choice == 'pansion') {
      url = '';
    }
    // Store all data with Param Name.
    var data = {'userid': userid, 'password': password, 'choice':widget.choice, 'sector': widget.sector};
    // Starting Web API Call.
    var response = await http.post(url, body: json.encode(data));

    // Getting Server response into variable.
    var message = jsonDecode(response.body);

    // If the Response Message is Matched.
    if (message == 'Login Matched') {
      // Hiding the CircularProgressIndicator.
      setState(() {
        visible = false;
      });
      
      // Navigate to Profile Screen & Sending Email to Next Screen.
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) =>
                  SeniorOfficialLogin(userid: useridController.text, choice: widget.choice, sector: widget.sector)));
    } else {
      // If Email or Password did not Matched.
      // Hiding the CircularProgressIndicator.
      setState(() {
        visible = false;
      });

      // Showing Alert Dialog with Response JSON Message.
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: new Text(message),
            actions: <Widget>[
              FlatButton(
                child: new Text("OK"),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
    }
  }
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
            child: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Text(
            'Welcome',
            style: TextStyle(
              fontSize: 70.0,
              color: Colors.black,
            ),
          ),
          Container(
              padding: EdgeInsets.only(top: 50),
              width: 330,
              child: TextField(
                controller: useridController,
                
                decoration: InputDecoration(
                    prefixIcon: Icon(Icons.person),
                    hintText: 'User Id',
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30.0))),
              )),
          Container(
              padding: EdgeInsets.only(top: 20, bottom: 30),
              width: 330,
              child: TextField(
                controller: passwordController,
                
                obscureText: true,
                decoration: InputDecoration(
                    prefixIcon: Icon(Icons.lock),
                    hintText: 'Password',
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30.0))),
              )),
          Container(
            height: 65,
            width: 330,
            child: RaisedButton(
              color: Colors.blue,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30.0),
              ),
              padding: EdgeInsets.all(0.0),
              onPressed: userLogin,
              child: Container(
                alignment: Alignment.center,
                width: 330,
                height: 65,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: <Color>[
                        Colors.blue[900],
                        Colors.blue[700],
                        Colors.blue[400],
                      ],
                    ),
                    borderRadius: BorderRadius.circular(30.0)),
                child: Text(
                  'Login',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 28, color: Colors.white),
                ),
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.only(top: 8),
            child: FlatButton(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30.0)),
              onPressed: () {},
              child: Text('Forgot your password?'),
            ),
          ),
          Visibility(
              visible: visible,
              child: Container(
                  margin: EdgeInsets.only(bottom: 30),
                  child: CircularProgressIndicator())),
        ],
      ),
    )));
  }
}
